STUDYSPARK — SMART STUDENT PLANNER

WHAT IT IS
A beginner-friendly, single-page web prototype that helps students add study tasks, set due dates and priorities, filter tasks, mark tasks complete, see completion progress, and run a 25-minute focus timer.

HOW TO RUN
1. Download index.html.
2. Double-click index.html, or right-click and open it with Chrome/Edge/Firefox.
3. Add a task using the form.
4. Mark tasks complete using the checkbox. Try the filters and focus timer.
5. Refresh the page: tasks should remain saved in the same browser using localStorage.

TECHNOLOGY
HTML, CSS, vanilla JavaScript, browser localStorage. No installation or internet connection is required to run the prototype.

LIMITATIONS
This is a front-end prototype. Data is saved only in the current browser on the current device; it does not sync between devices, use an online database, or have user accounts. The timer works while the page is open.

BEFORE HACKATHON SUBMISSION
Confirm the organizer's actual challenge statement and judging criteria. This project is a proposed general-purpose prototype and may need changes to match the official challenge. Test all features and submit only what you personally understand and can explain.
